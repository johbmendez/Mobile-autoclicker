# Mobile Auto Clicker (Android64 source)

This is an **experimental source project**, not a prebuilt `.geode` installer. It targets Android 64-bit and Geometry Dash 2.2081 using Geode SDK 5.x.

## Build in the cloud from a phone

1. Create a new repository on GitHub and upload the contents of this folder.
2. Open the repository's **Actions** tab and run **Build Android 64-bit Geode mod** (or push a commit to trigger it).
3. Open the completed workflow run and download the `Mobile-Auto-Clicker-Android64` artifact.
4. If the build succeeds, extract the artifact and install the `.geode` file through Geode's **Install from file** option.

## Important

- This source has **not been compiled or tested** in this environment, so a successful build is not guaranteed.
- It assumes Geometry Dash 2.2081 and a compatible Geode build.
- Test in practice mode/offline first. Automated input may be disallowed on some leaderboards or challenge rules.
- If the workflow fails, share the error log and I can help fix the source.
